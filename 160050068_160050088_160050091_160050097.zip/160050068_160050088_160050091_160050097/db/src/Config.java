
public class Config {
	
	public static final String url = "jdbc:postgresql://localhost:5680/postgres";
    public static final String user = "karan";
    public static final String password = "";
    public static final String semester = "Summer";
    public static final int year = 2018;

}
